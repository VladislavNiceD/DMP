
import discord#импорт модуля discord.py
from discord.ext import commands#импорт команд discord py
import random#импортируем модуль random для рандомизации

client = commands.Bot(command_prefix="!", intents=discord.Intents.all(), help_command=None)#префикс бота, и отключение стандартной команды help от discord py

@client.event#сообщаем о том, что внизу будет событие
async def on_ready():#если бот готов
	print("привет")#текст при запуске бота

@client.command()#сообщаем что внизу будет команда
async def help(ctx):#при команде !help
	await ctx.reply("помощь")#отправляем сообщение

#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36

client.run("MTAyNTczMTQwMTUxMDgzNDE4Ng.GH5FwG.rVa6l2mPQftT_ixMG4EGKampcL9WaM7G55O4gI")#запускаем бота с токеном...