import requests, time

def update(file):
    filename = file.split('/')[-1]
    r = requests.get(file, allow_redirects=True)
    open(filename, 'wb').write(r.content)
    
file=''
update(file)