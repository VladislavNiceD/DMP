from lib import *
while True:
	main()
	clear()