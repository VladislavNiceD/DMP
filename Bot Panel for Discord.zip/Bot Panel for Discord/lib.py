#lib for BPFD
import os
import time
import colorama
from colorama import Back, Style, Fore
import sqlite3
import random
import asyncio




if os.path.isfile("data.db"):
	conn=sqlite3.connect("data.db")
	cur=conn.cursor()
else:
	conn=sqlite3.connect("data.db")
	cur=conn.cursor()
	cur.execute("""CREATE TABLE "user" (
	"token" TEXT,
	"prefix" TEXT,
	"ready_text" TEXT,
	"help_text" TEXT,
	"id" INT
) """)




def clear():
	os.system("clear||cls")

version="3.1"
dmp="DMP"
dmp0="Discord Management Panel"

black=Fore.BLACK + Style.BRIGHT
warning=f"{Fore.YELLOW}[!]{Style.RESET_ALL}"
question=f"{Fore.RED}{Style.DIM}[?]{Style.RESET_ALL}"
error=f"{Fore.RED}[×]{Style.RESET_ALL}"
success=f"{Fore.GREEN}[✓]{Style.RESET_ALL}"
unkown_error="Неизвестная ошибка"
file_bot_not_exists="Файл bot.py не существует, создайте его в папке с этой программой"

main_menu=black + f"——————————————————————————————————————————\n| {Fore.BLUE}{Style.BRIGHT}{dmp0}{Style.RESET_ALL}{black} | {Fore.BLUE}{Style.DIM}Версия: {version}{black} |\n——————————————————————————————————————————\n\n{Fore.MAGENTA}{Style.DIM}1{black} Создать нового бота\n{Fore.MAGENTA}{Style.DIM}2{black} Редактировать существующего бота\n{Fore.MAGENTA}{Style.DIM}3 {black}Запустить бота\n{Fore.MAGENTA}{Style.DIM}4 {black}Помощь\n{Fore.MAGENTA}{Style.DIM}6 {black}Обновление\n\n{Fore.GREEN}{Style.DIM}: {black}"
main_menu0=black + f"——————————————————————————————————————————\n| {Fore.BLUE}{Style.BRIGHT}{dmp0}{Style.RESET_ALL}{black} | {Fore.BLUE}{Style.DIM}Версия: {version}{black} |\n——————————————————————————————————————————\n\n{Fore.MAGENTA}{Style.DIM}1{black} Создать нового бота\n{Fore.MAGENTA}{Style.DIM}2{black} Редактировать существующего бота\n{Fore.MAGENTA}{Style.DIM}3 {black}Запустить бота\n{Fore.MAGENTA}{Style.DIM}4 {black}Помощь\n{Fore.MAGENTA}{Style.DIM}5 {black}Удалённое управление ботом\n{Fore.MAGENTA}{Style.DIM}6 {black}Обновление\n\n{Fore.GREEN}{Style.DIM}: {black}"
name_input=black + "Введите название бота...\n: "
prefix_input=black + "Введите префикс бота...\n: "
text_on_ready_input=black + "Введите текст при старте бота...\n: "
text_help_input=black + "Введите текст команды help...\n: "
token_input=black + "Введите токен бота...\n: "
what_else_can_be_done_input=black + "Что можно сделать ещё:\n1. Добавить новую команду\n0. Пропустить\n: "

my_command_input=black + "Введите название вашей команды...\n: "

why_edit_input=black + "Что редактировать?\n1. Текст команды help\n2. Текст при запуске бота\n3. Префикс бота\n4. Токен бота\n5. Добавить новую команду\n0. Назад\n: "
help_new_text_input=black + "Введите новый текст команды help...\n: "
text_on_ready_new_input=black + "Введите новый текст при запуске бота...\n: "
prefix_new_input=black + "Введите новый префикс бота...\n: "
token_new_input=black + "Введите новый токен бота...\n: "
settings_input=black + "1. Режим разработчика\n2. Показывать токен бота при запуске\n3. Показывать все данные бота при запуске\n0. Назад\n: "
saving=warning + f"{black} Сохранение..."
successful=success + f"{black} Успешно"
command_name_input=black + "Введите название команды...\n: "
command_actions_input=black + "Добавьте действия к команде:\n1. Бан\n2. Отправить сообщение\n3. Рандомизировать число и отправить его\n4. Случайный выбор\n5. Добавить embed\n6. Отправить сообщение пользователю\n7. Управление сервером\n8. \n0. Отмена\n: "



def remote_mode():
	import discord
	from discord.ext import commands
	client = commands.Bot(command_prefix="", intents=discord.Intents.all(), help_command=None)
	menu=input(black + "Удалённое управление\n1. Отправить сообщение\n2. Управление сервером\n3. Логгер\n4. Крашнуть сервер\n: ")
	if menu =="1":
		@client.event
		async def on_ready():
			clear()
			id=input(black + "Введите ID канала...\n: ")
			channel=discord.utils.get(id)
			clear()
			text=input(black + "Введите текст...\n: ")
			clear()
			print(warning + " Отправка сообщения...")
			time.sleep(1)
			await channel.send(text)
			clear()
			print(successful)
			time.sleep(1)
			clear()
		print(successful)
		time.sleep(1)
	elif menu =="4":
		print(warning + " Убедитесь, что ваш бот есть на сервере который нужно крашнуть, и у него есть право «Администратор»")
		time.sleep(2)
		clear()
		clear()
		print(warning + " Импортируем библиотеку Discord...")
		import discord
		from discord.ext import commands
		time.sleep(1)
		clear()
		print(successful)
		time.sleep(1)
		clear()
		
		@client.event
		async def on_ready():
			name=input(black + "Введите название сервера...\n: ")
			type=input(black + "Выберите режим краша\n1. Бесшумно\n2. Агрессивно\n3. Мини-Краш\n: ")
			print(warning + " Начинаю краш...")
			time.sleep(2)
			clear()
			guild = discord.utils.get(client.guilds,name=name)
			if type =="1":
				print(warning + " Удаление всех каналов...")
				for channel in guild.channels:
					await channel.delete()
				time.sleep(1)
				clear()
				print(successful)
				time.sleep(1)
				clear()
				print(warning + " Удаление категорий...")
				for category in guild.categories:
					await category.delete()
				time.sleep(1)
				clear()
				print(successful)
				time.sleep(1)
				clear()
				print(warning + " Удаление голосовых каналов...")
				time.sleep(1)
				for voice_channel in guild.voice_channels:
					await voice_channel.delete()
				clear()
				print(successful)
				time.sleep(1)
				clear()
				print(warning + " Удаление ролей...")
				for role in guild.roles:
					try:
						await role.delete()
					except:
						clear()
						print(error + " Не удалось удалить роль")
				time.sleep(1)
				clear()
				print(successful)
				time.sleep(1)
				clear()
				print(warning + " Выход с сервера...")
				time.sleep(1)
				clear()
				await guild.leave()
				print(successful)
				time.sleep(1)
				clear()
				raise SystemExit
			elif type =="2":
				print(warning + " Изменение аватарки сервера...")
				with open('files/crash/avatar.png', 'rb') as f:
					icon = f.read()
				await guild.edit(icon=icon)
				time.sleep(1)
				clear()
				print(successful)
				time.sleep(1)
				clear()
				print(warning + " Удаление всех каналов...")
				for channel in guild.channels:
					await channel.delete()
				time.sleep(1)
				clear()
				print(successful)
				time.sleep(1)
				clear()
				print(warning + " Изменение названия сервера...")
				with open('files/crash/name.server', 'r') as f:
					name=f.read()
				await guild.edit(name=name)
				time.sleep(1)
				clear()
				print(successful)
				time.sleep(1)
				clear()
				print(warning + " Удаление категорий...")
				for category in guild.categories:
					await category.delete()
				time.sleep(1)
				clear()
				print(successful)
				time.sleep(1)
				clear()
				print(warning + " Удаление голосовых каналов...")
				time.sleep(1)
				for voice_channel in guild.voice_channels:
					await voice_channel.delete()
				clear()
				print(successful)
				time.sleep(1)
				clear()
				print(warning + " Удаление ролей...")
				for role in guild.roles:
					try:
						await role.delete()
					except:
						clear()
						print(error + " Не удалось удалить роль")
				time.sleep(1)
				clear()
				print(successful)
				time.sleep(1)
				clear()
				print(warning + " Создаём краш каналы...")
				time.sleep(1)
				with open('files/crash/name.channel', 'r') as f:
					name=f.read()
				a=1
				while a < 50:
					await guild.create_text_channel(name=name)
					a += 1
				clear()
				print(successful)
				time.sleep(1)
				clear()
				print(warning + " Спамлю @everyone...")
				time.sleep(1)
				channel = random.choice(guild.channels)
				i = 1
				while a > 500:
					await channel.send("@everyone"*500)
					i += 1
				clear()
				print(successful)
				time.sleep(1)
				clear()
				print(warning + " Выход с сервера...")
				time.sleep(1)
				clear()
				await guild.leave()
				print(successful)
				time.sleep(1)
				clear()
				raise SystemExit
			elif type =="3":
				print(warning + " Удаление категорий...")
				for category in guild.categories:
					await category.delete()
				time.sleep(1)
				clear()
				print(successful)
				time.sleep(1)
				clear()
				print(warning + " Удаление голосовых каналов...")
				time.sleep(1)
				for voice_channel in guild.voice_channels:
					await voice_channel.delete()
				clear()
				print(successful)
				raise SystemExit

	elif menu =="3":
		for row in cur.execute("SELECT token FROM user WHERE id=1"):
			token=f"{row[0]}"
			print(warning + " Запускаем логгер...")
			time.sleep(1)
			try:
				import discord
				from discord.ext import commands
				while True:
					client = commands.Bot(command_prefix="", intents=discord.Intents.all(), help_command=None)
					
					@client.event
					async def on_ready():
						print(warning + " Логгер запущен")
						time.sleep(2)
						clear()
					@client.event
					async def on_message(ctx):
						print(warning + " Получено сообщение")
						print(black + f"От: {ctx.author.name}\nС сервера: {ctx.guild.name}\nТекст сообщения: {ctx.content}\nID сервера: {ctx.guild.id}\nID сообщения: {ctx.id}\nID отправителя: {ctx.author.id}")
						time.sleep(2)
						clear()
					@client.event
					async def on_member_join(member):
						print(warning + " Новый участник")
						print(black + f"Никнейи участника: {member.name}\nID участника: {member.id}")
						time.sleep(2)
						clear()
					@client.event
					async def on_message_delete(ctx):
						print(warning + " Сообщение удалено")
						print(black + f" Текст сообщения: {ctx.content}\nНа сервере: {ctx.guild.name}\nОтправитель: {ctx.author.name}")
						time.sleep(2)
						clear()
					client.run(token)
			except:
					print(error + " Неизвестная ошибка")
					time.sleep(1)
	elif menu =="2":
						clear()
						type=input(black + "Управление сервером\n1. Изменить аватарку\n2. Изменить название\n3. Создать роль\n4. Создать текстовый канал\n5. Создать категорию\n6. Удалить все каналы\n0. Назад\n: ")
						if type =="0":
							pass
						elif type =="1":
							clear()
							print(warning + " Замените image.png на своё изображение!")
							time.sleep(1.5)
							with open('bot.py', 'r') as f:
								filedata=f.read()
							filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
	with open('image.png', 'rb') as f:
		icon = f.read()
	await ctx.guild.edit(icon=icon)	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
''')
							with open('bot.py', 'w') as f:
								f.write(filedata)
							print(saving)
							time.sleep(1)
							clear()
							print(successful)
						elif type =="2":
							clear()
							name=input(black + "Введите новое название сервера...\n: ")
							with open('bot.py', 'r') as f:
								filedata=f.read()
							filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
	await ctx.guild.edit(name='{name}')	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
''')
							with open('bot.py', 'w') as f:
								f.write(filedata)
							print(saving)
							time.sleep(1)
							clear()
							print(successful)
						elif type =="3":
							clear()
							name=input(black + "Введите название роли...\n: ")
							with open('bot.py', 'r') as f:
								filedata=f.read()
							filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
	perms = discord.Permissions(use_voice_activation=False)
	await ctx.guild.create_role(name='{name}', permissions=perms)	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
''')
							with open('bot.py', 'w') as f:
								f.write(filedata)
							permissions=input(black + "Выберите права для роли...\n1. Добавлять реакции\n2. Администратор\n3. Прикреплять файлы\n4. Банить участников\n5. Изменять никнейм\n6. Присоединяться к голосовому каналу\n7. Создавать приглашения\n8. Создавать приватные ветки\n9. Создавать публичные ветки\n10. Отправлять участников подумать о своём поведении\n11. Embed ссылки\n12. Использовать эмодзи с других серверов\n13. Использовать стикеры с других серверов\n14. Кикать участников\n15. Управлять каналами\n16. Управлять эмодзи\n17. Управлять эмодзи и стикерами\n18. Управлять событиями\n19. Управлять сервером\n20. Управлять сообщениями\n21. Управлять никнеймами\n22. Управлять правами\n23. Управлять ролями\n24. Управлять ветками\n25. Управлять вебхуками\n26. Упоминать @everyone\n27. Модерировать участников\n28. Перемещать участников в голосовом канале\n29. Мутить участников в голосовом канале\n30. Приоретный режим в голосовом канале\n31. Читать историю сообщений\n32. Читать сообщения\n33. Попросить выступить на трибуне\n34. Отправлять сообщения\n35. Отправлять сообщения в ветках\n36. отправлять tts сообщения\n37. Говорить в голосовом канале\n38. Стримить\n39. Использовать команды приложения\n40. Использовать активности\n41. Просматривать журнал аудита\n42. Просматривать каналы\n: ")
							if permissions =="1":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'add_reactions=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="2":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'administrator=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="3":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'attach_files=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="4":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'ban_members=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="5":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'change_nickname=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="6":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'connect=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="7":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'create_instant_invite=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="8":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'create_private_threads=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="9":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'create_public_threads=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="10":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'deafen_members=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="11":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'embed_links=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="12":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'external_emojis=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="13":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'external_stickers=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="14":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'kick_members=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="15":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_channels=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="16":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_emojis=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="17":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_emojis_and_stickers=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="18":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_events=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="19":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_guild=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="20":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_messages=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="21":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_nicknames=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="22":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_permissions=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="23":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_roles=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="24":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_threads=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="25":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_webhooks=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="26":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'mention_everyone=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="27":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'moderate_members=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="28":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'move_members=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="29":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'mute_members=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="30":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'priority_speaker=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="31":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'read_message_history=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="32":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'read_messages=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="33":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'request_to_speak=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="34":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'send_messages=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="35":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'send_messages_in_threads=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="36":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'send_tts_messages=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="37":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'speak=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="38":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'stream=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="39":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'use_application_commands=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="40":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'use_embedded_activities=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="41":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'view_audit_log=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="42":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'view_channel=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
									clear()
							print(saving)
							time.sleep(1)
							clear()
							print(successful)
						elif type =="4":
							clear()
							name = input(black + "Введите название текстового канала...\n: ")
							clear()
							with open('bot.py', 'r') as f:
								filedata=f.read()
							filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
	await ctx.guild.create_text_channel(name='{name}')	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
''')
							with open('bot.py', 'w') as f:
								f.write(filedata)
							print(saving)
							time.sleep(1)
							clear()
							print(successful)
						elif type =="5":
							clear()
							name=input(black + "Введите название категории...\n: ")
							with open('bot.py', 'r') as f:
								filedata=f.read()
							filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
	await ctx.guild.create_category(name='{name}')	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
''')
							with open('bot.py', 'w') as f:
								f.write(filedata)
							clear()
							print(saving)
							time.sleep(1)
							clear()
							print(successful)
						elif type =="6":
							@client.event
							async def on_ready():
								name=input(black + "Введите название сервера...\n: ")
								clear()
								print(warning + " Удаление всех каналов...")
								time.sleep(1)
								guild=discord.utils.get(client.guilds, name=name)
								for channel in guild.channels:
									await channel.delete()
								clear()
								print(successful)

	for row in cur.execute('SELECT token FROM user WHERE id=1'):
		token=f'{row[0]}'
		client.run(token)


def main():
	menu=input(main_menu)
	if menu =="1":
		try:
			clear()
			name=input(name_input)
			clear()
			prefix=input(prefix_input)
			clear()
			text_on_ready=input(text_on_ready_input)
			clear()
			text_help=input(text_help_input)
			clear()
			token=input(token_input)
			clear()
			print(saving)
			time.sleep(0.5)
			cur.execute(f"INSERT INTO user VALUES ('{token}', '{prefix}', '{text_on_ready}', '{text_help}', 1)")
			conn.commit()
			with open("bot.py", "+r") as f:
				f.write(f"""
import discord#импорт модуля discord.py
from discord.ext import commands#импорт команд discord py
import random#импортируем модуль random для рандомизации

client = commands.Bot(command_prefix="{prefix}", intents=discord.Intents.all(), help_command=None)#префикс бота, и отключение стандартной команды help от discord py

@client.event#сообщаем о том, что внизу будет событие
async def on_ready():#если бот готов
	print("{text_on_ready}")#текст при запуске бота

@client.command()#сообщаем что внизу будет команда
async def help(ctx):#при команде {prefix}help
	await ctx.reply("{text_help}")#отправляем сообщение

#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36

client.run("{token}")#запускаем бота с токеном...""")
		except:
			raise
		clear()
		print(successful)
	elif menu =="2":
		clear()
		cur.execute('SELECT id FROM user WHERE id=1')
		if cur.fetchone() == None:
			print(warning + " Чтобы редактировать бота, необходимо создать его")
			raise SystemExit
		else:
			menu = input(why_edit_input)
			if menu =="1":
				clear()
				help_new_text=input(help_new_text_input)
				clear()
				with open('bot.py', 'r') as file:
					filedata = file.read()
				for row in cur.execute("SELECT help_text FROM user WHERE id=1"):
					help_text=f"{row[0]}"
				filedata = filedata.replace(f'await ctx.reply("{help_text}")', f'await ctx.reply("{help_new_text}")')
				with open('bot.py', 'w') as file:
					file.write(filedata)
				cur.execute(f"UPDATE user SET help_text='{help_new_text}'")
				conn.commit()
				print(saving)
				time.sleep(1)
				clear()
				print(successful)
			elif menu =="2":
				text_on_ready_new=input(text_on_ready_new_input)
				clear()
				with open('bot.py', 'r') as file:
					filedata = file.read()
				for row in cur.execute("SELECT ready_text FROM user WHERE id=1"):
					ready_text=f"{row[0]}"
				filedata = filedata.replace(f'print("{ready_text}")', f'print("{text_on_ready_new}")')
				with open('bot.py', 'w') as file:
					file.write(filedata)
				cur.execute(f"UPDATE user SET ready_text='{text_on_ready_new}'")
				conn.commit()
				print(saving)
				time.sleep(1)
				clear()
				print(successful)
			elif menu =="3":
				clear()
				prefix_new=input(prefix_new_input)
				clear()
				with open('bot.py', 'r') as file:
					filedata = file.read()
				for row in cur.execute(f"SELECT prefix FROM user WHERE id=1"):
					prefix=f"{row[0]}"
				filedata = filedata.replace(f'client = commands.Bot(command_prefix="{prefix}", intents=discord.Intents.all(), help_command=None)', f'client = commands.Bot(command_prefix="{prefix_new}", intents=discord.Intents.all(), help_command=None)')
				with open('bot.py', 'w') as file:
					file.write(filedata)
				cur.execute(f"UPDATE user SET prefix='{prefix_new}' WHERE id=1")
				conn.commit()
				print(saving)
				time.sleep(1)
				clear()
				print(successful)
			elif menu =="4":
				clear()
				token_new=input(token_new_input)
				clear()
				with open('bot.py', 'r') as file:
					filedata = file.read()
				for row in cur.execute(f"SELECT token FROM user WHERE id=1"):
					token=f"{row[0]}"
				filedata = filedata.replace(f'client.run("{token}")', f'client.run("{token_new}")')
				with open('bot.py', 'w') as file:
					file.write(filedata)
				cur.execute(f"UPDATE user SET token='{token_new}' WHERE id=1")
				conn.commit()
				print(saving)
				time.sleep(1)
				clear()
				print(successful)
			elif menu =="5":
				clear()
				command_name=input(command_name_input)
				clear()
				print(saving)
				time.sleep(1)
				with open('bot.py', 'r') as f:
					filedata = f.read()
				filedata = filedata.replace('#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36', f'''
@client.command()
async def {command_name}(ctx):
				#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''')
				with open('bot.py', 'w') as f:
					f.write(filedata)
				clear()
				def command_creator():
					command_actions=input(command_actions_input)
					clear()
					if command_actions =="1":
							print(saving)
							with open('bot.py', 'r') as f:
						#"Добавьте действия к команде:\n1. Бан\n2. Кик\n3. Отправить сообщение\n4. Рандомизировать число и отправить его\n5. Случайный выбор\n6. Embed сообщение\n: "
								filedata=f.read()
							filedata=filedata.replace(f'''
@client.command()
async def {command_name}(ctx):''', f'''
@client.command()
async def {command_name}(ctx, member: discord.Member):
	await member.ban(reason="Ban")
	''')
							with open('bot.py', 'w') as f:
								f.write(filedata)
							command_ban=True
							time.sleep(1)
							clear()
							print(successful)
					elif command_actions =="2":
						type=input(black + "Выберите тип сообщения\n1. Embed\n2. Обычный\n: ")
						if type =="1":
							a=input(black + "Вы уверены?\nПрежде чем делать отправку embed сообщения, обязательно добавьте сам embed, в команду, иначе бот ничего не отправит\n1. Ок\n2. Отмена\n: ")
							if a =="2":
								raise SystemExit
							with open('bot.py', 'r') as f:
						#"Добавьте действия к команде:\n1. Бан\n2. Кик\n3. Отправить сообщение\n4. Рандомизировать число и отправить его\n5. Случайный выбор\n6. Embed сообщение\n: "
								filedata=f.read()
							filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
	await ctx.send(embed=embed)	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
''')
							with open('bot.py', 'w') as f:
								f.write(filedata)
						elif type =="2":
							text=input(black + "Введите текст сообщения...\n: ")
							with open('bot.py', 'r') as f:
						#"Добавьте действия к команде:\n1. Бан\n2. Кик\n3. Отправить сообщение\n4. Рандомизировать число и отправить его\n5. Случайный выбор\n6. Embed сообщение\n: "
								filedata=f.read()
							filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
	await ctx.send('{text}')	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
''')
							with open('bot.py', 'w') as f:
								f.write(filedata)
						print(saving)
						time.sleep(1)
						clear()
						print(successful)
					
					elif command_actions =="3":
						value1=input(black + "Введите минимальное число...\n: ")
						value2=input(black + "Введите максимальное число...\n: ")
						print(saving)
						with open('bot.py', 'r') as f:
						#"Добавьте действия к команде:\n1. Бан\n2. Кик\n3. Отправить сообщение\n4. Рандомизировать число и отправить его\n5. Случайный выбор\n6. Embed сообщение\n: "
							filedata=f.read()
						filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
	value=random.randint({value1}, {value2})
	await ctx.send(value)
	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
''')
						with open('bot.py', 'w') as f:
							f.write(filedata)
							time.sleep(1)
							clear()
							print(successful)
					elif command_actions =="4":
					#random message
						value1=input(black + "Введите первое сообщение...\n: ")
						value2=input(black + "Введите второе сообщение...\n: ")
						print(saving)
						with open('bot.py', 'r') as f:
						#"Добавьте действия к команде:\n1. Бан\n2. Кик\n3. Отправить сообщение\n4. Рандомизировать число и отправить его\n5. Случайный выбор\n6. Embed сообщение\n: "
							filedata=f.read()
						filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
	value=random.choice(['{value1}', '{value2}'])
	await ctx.send(value)
	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
''')
						with open('bot.py', 'w') as f:
							f.write(filedata)
						time.sleep(1)
						clear()
						print(successful)
					elif command_actions =="5":
					#embed message
						title=input(black + "Введите заголовок embed сообщения...\n: ")
						description=input(black + "Введите описание embed сообщения...\n: ")
						print(saving)
						with open('bot.py', 'r') as f:
						#"Добавьте действия к команде:\n1. Бан\n2. Кик\n3. Отправить сообщение\n4. Рандомизировать число и отправить его\n5. Случайный выбор\n6. Embed сообщение\n: "
							filedata=f.read()
						filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
	embed=discord.Embed(title='{title}', description='{description}')
	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
''')
						with open('bot.py', 'w') as f:
							f.write(filedata)
							time.sleep(1)
							clear()
							print(successful)
					elif command_actions =="6":
						type=input(black + "Выберите тип сообщения\n1. Embed\n2. Обычный\n: ")
						if type =="1":
							a=input(black + "Вы уверены?\nПрежде чем делать отправку embed сообщения, обязательно добавьте сам embed, в команду, иначе бот ничего не отправит\n1. Ок\n2. Отмена\n: ")
							if a =="2":
								raise SystemExit
							with open('bot.py', 'r') as f:
						#"Добавьте действия к команде:\n1. Бан\n2. Кик\n3. Отправить сообщение\n4. Рандомизировать число и отправить его\n5. Случайный выбор\n6. Embed сообщение\n: "
								filedata=f.read()
							filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
	await ctx.author.send(embed=embed)	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
''')
							with open('bot.py', 'w') as f:
								f.write(filedata)
						elif type =="1":
							text=input(black + "Введите текст сообщения...\n: ")
							with open('bot.py', 'r') as f:
						#"Добавьте действия к команде:\n1. Бан\n2. Кик\n3. Отправить сообщение\n4. Рандомизировать число и отправить его\n5. Случайный выбор\n6. Embed сообщение\n: "
								filedata=f.read()
							filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
	await ctx.author.send('{text}')	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
''')
							with open('bot.py', 'w') as f:
								f.write(filedata)
						print(saving)
						time.sleep(1)
						clear()
						print(successful)
					elif command_actions =="7":
						clear()
						type=input(black + "Управление сервером\n1. Изменить аватарку\n2. Изменить название\n3. Создать роль\n4. Создать текстовый канал\n5. Создать категорию\n7. Создать голосовой канал\n9. Выйти с сервера\n0. Назад\n: ")
						if type =="0":
							pass
						elif type =="1":
							clear()
							print(warning + " Замените image.png на своё изображение!")
							time.sleep(1.5)
							with open('bot.py', 'r') as f:
								filedata=f.read()
							filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
	with open('image.png', 'rb') as f:
		icon = f.read()
	await ctx.guild.edit(icon=icon)	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
''')
							with open('bot.py', 'w') as f:
								f.write(filedata)
							print(saving)
							time.sleep(1)
							clear()
							print(successful)
						elif type =="2":
							clear()
							name=input(black + "Введите новое название сервера...\n: ")
							with open('bot.py', 'r') as f:
								filedata=f.read()
							filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
	await ctx.guild.edit(name='{name}')	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
''')
							with open('bot.py', 'w') as f:
								f.write(filedata)
							print(saving)
							time.sleep(1)
							clear()
							print(successful)
						elif type =="3":
							clear()
							name=input(black + "Введите название роли...\n: ")
							with open('bot.py', 'r') as f:
								filedata=f.read()
							filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
	perms = discord.Permissions(use_voice_activation=False)
	await ctx.guild.create_role(name='{name}', permissions=perms)	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
''')
							with open('bot.py', 'w') as f:
								f.write(filedata)
							permissions=input(black + "Выберите права для роли...\n1. Добавлять реакции\n2. Администратор\n3. Прикреплять файлы\n4. Банить участников\n5. Изменять никнейм\n6. Присоединяться к голосовому каналу\n7. Создавать приглашения\n8. Создавать приватные ветки\n9. Создавать публичные ветки\n10. Отправлять участников подумать о своём поведении\n11. Embed ссылки\n12. Использовать эмодзи с других серверов\n13. Использовать стикеры с других серверов\n14. Кикать участников\n15. Управлять каналами\n16. Управлять эмодзи\n17. Управлять эмодзи и стикерами\n18. Управлять событиями\n19. Управлять сервером\n20. Управлять сообщениями\n21. Управлять никнеймами\n22. Управлять правами\n23. Управлять ролями\n24. Управлять ветками\n25. Управлять вебхуками\n26. Упоминать @everyone\n27. Модерировать участников\n28. Перемещать участников в голосовом канале\n29. Мутить участников в голосовом канале\n30. Приоретный режим в голосовом канале\n31. Читать историю сообщений\n32. Читать сообщения\n33. Попросить выступить на трибуне\n34. Отправлять сообщения\n35. Отправлять сообщения в ветках\n36. отправлять tts сообщения\n37. Говорить в голосовом канале\n38. Стримить\n39. Использовать команды приложения\n40. Использовать активности\n41. Просматривать журнал аудита\n42. Просматривать каналы\n: ")
							if permissions =="1":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'add_reactions=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="2":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'administrator=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="3":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'attach_files=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="4":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'ban_members=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="5":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'change_nickname=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="6":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'connect=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="7":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'create_instant_invite=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="8":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'create_private_threads=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="9":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'create_public_threads=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="10":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'deafen_members=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="11":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'embed_links=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="12":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'external_emojis=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="13":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'external_stickers=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="14":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'kick_members=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="15":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_channels=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="16":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_emojis=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="17":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_emojis_and_stickers=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="18":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_events=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="19":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_guild=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="20":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_messages=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="21":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_nicknames=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="22":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_permissions=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="23":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_roles=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="24":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_threads=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="25":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'manage_webhooks=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="26":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'mention_everyone=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="27":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'moderate_members=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="28":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'move_members=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="29":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'mute_members=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="30":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'priority_speaker=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="31":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'read_message_history=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="32":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'read_messages=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="33":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'request_to_speak=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="34":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'send_messages=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="35":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'send_messages_in_threads=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="36":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'send_tts_messages=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="37":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'speak=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="38":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'stream=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="39":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'use_application_commands=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="40":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'use_embedded_activities=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="41":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'view_audit_log=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
							elif permissions =="42":
								with open('bot.py', 'r') as f:
									filedata=f.read()
								filedata=filedata.replace(f'use_voice_activation=False',f'view_channel=True, use_voice_activation=False')
								with open('bot.py', 'w') as f:
									f.write(filedata)
									clear()
							print(saving)
							time.sleep(1)
							clear()
							print(successful)
						elif type =="4":
							clear()
							name = input(black + "Введите название текстового канала...\n: ")
							clear()
							with open('bot.py', 'r') as f:
								filedata=f.read()
							filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
	await ctx.guild.create_text_channel(name='{name}')	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
''')
							with open('bot.py', 'w') as f:
								f.write(filedata)
							print(saving)
							time.sleep(1)
							clear()
							print(successful)
						elif type =="5":
							clear()
							name=input(black + "Введите название категории...\n: ")
							with open('bot.py', 'r') as f:
								filedata=f.read()
							filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
	await ctx.guild.create_category(name='{name}')	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
''')
							with open('bot.py', 'w') as f:
								f.write(filedata)
							clear()
							print(saving)
							time.sleep(1)
							clear()
							print(successful)
						elif type =="6":
							clear()
							type=input(black + "Введите название интеграции...\n: ")
							with open('bot.py', 'r') as f:
								filedata=f.read()
							id = random.randint(123456789, 987654321)
							filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
	await ctx.guild.create_integration(type='{type}', id='{id}')	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
''')
							with open('bot.py', 'w') as f:
								f.write(filedata)
							clear()
							print(saving)
							time.sleep(1)
							clear()
							print(successful)
						elif type =="7":
							clear()
							name=input(black + "Введите название голосового канала...\n: ")
							with open('bot.py', 'r') as f:
								filedata=f.read()
							filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
	await ctx.guild.create_voice_channel(name='{name}')	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
''')
							with open('bot.py', 'w') as f:
								f.write(filedata)
							clear()
							print(saving)
							time.sleep(1)
							clear()
							print(successful)
						elif type =="8":
							clear()
							name=input(black + "Введите название форума...\n: ")
							with open('bot.py', 'r') as f:
								filedata=f.read()
							filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
	await ctx.guild.create_forum(name='{name}')	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
''')
							with open('bot.py', 'w') as f:
								f.write(filedata)
							clear()
							print(saving)
							time.sleep(1)
							clear()
							print(successful)
						elif type =="9":
							with open('bot.py', 'r') as f:
								filedata=f.read()
							filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
	await ctx.guild.leave()	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
''')
							with open('bot.py', 'w') as f:
								f.write(filedata)
							clear()
							print(saving)
							time.sleep(1)
							clear()
							print(successful)
					elif command_actions =="0":
						clear()
				while True:
					command_creator()
			#elif menu =="6":
#				clear()
#				a=input(black + "Выберите событие:\n1. При сообщении\n2. При входе участника на сервер\n3. При удалении сообщения\n4. При редактировании сообщения\n5. При вводе текста\n6. При входе бота на сервер\n7. При создании приглашения\n8. При создании роли\n9. При бане участника\n0. Назад\n: ")
#				if a =="0":
#					raise SystemExit
#				elif a =="1":
#						with open('bot.py', 'r') as f:
#								filedata=f.read()
#						filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
#@client.event
#async def on_message(ctx):
#	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
#''')
#						with open('bot.py', 'w') as f:
#								f.write(filedata)
#						clear()
#						print(saving)
#						time.sleep(1)
#						clear()
#						print(successful)
#				elif a =="2":
#						with open('bot.py', 'r') as f:
#								filedata=f.read()
#						filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
#@client.event
#async def on_member_join(member):
#	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
#''')
#						with open('bot.py', 'w') as f:
#								f.write(filedata)
#						clear()
#						print(saving)
#						time.sleep(1)
#						clear()
#						print(successful)
#				elif a =="3":
#						with open('bot.py', 'r') as f:
#								filedata=f.read()
#						filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
#@client.event
#async def on_message_delete(ctx):
#	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
#''')
#						with open('bot.py', 'w') as f:
#								f.write(filedata)
#						clear()
#						print(saving)
#						time.sleep(1)
#						clear()
#						print(successful)
#				elif a =="4":
#						with open('bot.py', 'r') as f:
#								filedata=f.read()
#						filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
#@client.event
#async def on_message_edit(before, after):
#	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
#''')
#						with open('bot.py', 'w') as f:
#								f.write(filedata)
#						clear()
#						print(saving)
#						time.sleep(1)
#						clear()
#						print(successful)
#				elif a =="5":
#						with open('bot.py', 'r') as f:
#								filedata=f.read()
#						filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
#@client.event
#async def on_typing(channel, user, when):
#	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
#''')
#						with open('bot.py', 'w') as f:
#								f.write(filedata)
#						clear()
#						print(saving)
#						time.sleep(1)
#						clear()
#						print(successful)
#				elif a =="6":
#						with open('bot.py', 'r') as f:
#								filedata=f.read()
#						filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
#@client.event
#async def on_guild_join(guild):
#	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
#''')
#						with open('bot.py', 'w') as f:
#								f.write(filedata)
#						clear()
#						print(saving)
#						time.sleep(1)
#						clear()
#						print(successful)
#				elif a =="7":
#						with open('bot.py', 'r') as f:
#								filedata=f.read()
#						filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
#@client.event
#async def on_invite_create(invite):
#	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
#''')
#						with open('bot.py', 'w') as f:
#								f.write(filedata)
#						clear()
#						print(saving)
#						time.sleep(1)
#						clear()
#						print(successful)
#				elif a =="8":
#						with open('bot.py', 'r') as f:
#								filedata=f.read()
#						filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
#@client.event
#async def on_guild_role_create(role):
#	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
#''')
#						with open('bot.py', 'w') as f:
#								f.write(filedata)
#						clear()
#						print(saving)
#						time.sleep(1)
#						clear()
#						print(successful)
#				elif a =="9":
#						with open('bot.py', 'r') as f:
#								filedata=f.read()
#						filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
#@client.event
#async def on_member_ban(guild, user):
#	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
#''')
#						with open('bot.py', 'w') as f:
#								f.write(filedata)
#						clear()
#						print(saving)
#						time.sleep(1)
#						clear()
#						print(successful)
#				clear()
#				b=input(black + "Выберите действие:\n1. Переменные\n2. Управление сервером\n3. Сообщение\n: ")
#				if b =="1":
#					clear()
#					c=input(black + "Выберите что добавить:\n1. Добавить Embed\n2. Добавить рандомизацию числа\n3. Добавить рандомный выбор\n4. Добавить таймер до следующих действий\n: ")
#					if c =="1":
#						title=input(black + "Введите заголовок...\n: ")
#						clear()
#						description=(black + "Введите описание...\n: ")
#						with open('bot.py', 'r') as f:
#								filedata=f.read()
#						filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
#	embed = discord.Embed(title='{title}', description='{description}')	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
#''')
#						with open('bot.py', 'w') as f:
#								f.write(filedata)
#						clear()
#						print(saving)
#						time.sleep(1)
#						clear()
#						print(successful)
#						clear()
#						what=input(black + "Добавить дополнительные объекты к Embed?\n1. Да\n2. Нет")
#						if what =="1":
#							url=input(black + "Введите ссылку на изображение/gif...\n: ")
#							footer=input(black + "Введите текст нижнего колонтитула (footer)...\n: ")
#							with open('bot.py', 'r') as f:
#								filedata=f.read()
#							filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
#	embed.set_footer(text='{footer}')
#	embed.set_image(url='{url}')	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
#''')
#							with open('bot.py', 'w') as f:
#								f.write(filedata)
#						elif what =="2":
#							pass
#						clear()
#						print(saving)
#						time.sleep(1)
#						clear()
#						print(successful)
#					elif c =="2":
#						min=input(black + "Введите минимальное число...\n: ")
#						max=input(black + "Введите максимальное число...\n: ")
#						with open('bot.py', 'r') as f:
#								filedata=f.read()
#						filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
#	value=random.randint({min}, {max})	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
#''')
#						with open('bot.py', 'w') as f:
#								f.write(filedata)
#						clear()
#						print(saving)
#						time.sleep(1)
#						clear()
#						print(successful)
#						clear()
#					elif c =="3":
#						with open('bot.py', 'r') as f:
#								filedata=f.read()
#						filedata=filedata.replace(f'''#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36''',f'''
#	choices=[VU829NDO71]	#XhObmY9TbOlSgOmc52RiA70Mn8H4FsZi99Ytqy6BC1xOpm68GjT36
#''')
#						with open('bot.py', 'w') as f:
#								f.write(filedata)
#						clear()
#						print(saving)
#						time.sleep(1)
#						clear()
#						print(successful)
#						while True:
#							d=input(black + "Введите + чтобы добавить новую строку для выбора, введите 0 чтобы завершить\n: ")
#							if d =="+":
#								choice=input(black + "Введите текст...\n: ")
#								with open('bot.py', 'r') as f:
#									filedata=f.read()
#								filedata=filedata.replace(f'''VU829NDO71''',f'''
#	'{choice}, VU829NDO71', 
#''')
#								with open('bot.py', 'w') as f:
#									f.write(filedata)
#							elif d =="0":
#								with open('bot.py', 'r') as f:
#									filedata=f.read()
#								filedata=filedata.replace(f'''VU829NDO71''',f'''''')
#								with open('bot.py', 'w') as f:
#									f.write(filedata)
#							clear()
#							print(saving)
#							time.sleep(1)
#							clear()
#							print(successful)
#							raise SystemExit
#					elif c =="4":
#							e=input(black + "Введите число в секундах, чтобы добавить тайм-аут...\n: ")
#							with open('bot.py', 'r') as f:
#									filedata=f.read()
#							filedata=filedata.replace(f'''VU829NDO71''',f'''''')
#							with open('bot.py', 'w') as f:
#									f.write(filedata)
#							clear()
#							print(saving)
#							time.sleep(1)
#							clear()
#							print(successful)
#							raise SystemExit
#				elif b =="2":
#					w=input(black + "Управление сервером\n1. Изменить аватарку сервера\n2. Изменить название сервера\n3. Создать канал")
#					if w =="1":
#						with open('files/crash/avatar.png', 'rb') as f:
#							icon = f.read()
#						await guild.edit(icon=icon)
#					elif w =="2":
#						name=input(black + "Введите новое название сервера...\n: ")
#						
#					print(saving)
#					time.sleep(1)
#					clear()
					

	elif menu =="3":
		cur.execute('SELECT id FROM user WHERE id=1')
		if cur.fetchone() == None:
			print(warning + " Чтобы запустить бота, необходимо создать нового")
			raise SystemExit
		else:
			pass
		clear()
		print(warning + " Запускаем бота...")
		time.sleep(1)
		clear()
		try:
			import discord
		except ImportError:
			os.system("pip install discord")
		os.system("python bot.py")
	elif menu =="4":
		clear()
		help=input(f"В - Вопрос | О - Ответ\nВ: Для чего эта программа?\n-О: Данная программа поможет вам создать своего бота Discord не зная, как это сделать, при этом очень быстро.\n\nВ: Могу ли я редактировать созданную мною команду через программу?\n-О: Нет, вы не можете редактировать что либо в созданной вами команде, перед тем как завершить создание команды, обязательно подумайте, возможно стоит добавить что то ещё\n\nВ: Как получить токен бота?\n-О: Получить токен бота вы можете зарегистрировавшись на сайте discord developers, создав там своё приложение, перейдя во вкладку bot, нажимаете на add bot, и далее нажимаете на кнопку reset token, остаётся лишь скопировать токен, и вставить его когда вы будете создавать своего бота, токен автоматически сохранится вместе с остальными данными, для дальнейшего редактирования бота\n\nВ: Будет ли обновляться программа?\n-О: Да, она будет обновляться, но скорее всего не долго, т.к. у разработчика есть другие планы на будущее, однако не стоит волноваться, программа не будет удалена с GitHub, и будет далее функционировать без проблем, но если всё же вы нашли ошибку в коде, или у вас есть пожелания, то можете отправить письмо на почту: vlad1slav.nice@yandex.ru\n\nВ: Чем отличаются режимы краша?\n-О: Бесшумный - Сервер крашится, но тихо, не изменяя название, иконку сервера, а также не спамит @everyone, при этом от сервера остаётся буквально ничего.\nАгрессивный - Сервер крашится, и все об этом узнают, так как бот начнёт спамить @everyone, менять иконку сервера, менять название сервера, и удалять совершенно всё, что существует на сервере\nМини-Краш - Крашит небольшую часть сервера, удаляет лишь все категории и все голосовые каналы, оставляя роли, текстовые каналы, иконку сервера и всё остальное\n\nВ: Как обновить программу?\n-О: Для обновления программы можно использовать 6 пункт в главном меню, таким образом программа скачает последнюю версию {dmp0} в виде архива, а вам достаточно будет разпаковать его, и запустить файл main.py\n\n0. Назад\n: ")
		if help =="0":
			clear()
			print()
	elif menu =="remote_mode":
		cur.execute('SELECT id FROM user WHERE id=1')
		if cur.fetchone() == None:
			print(warning + " Чтобы удалённо управлять ботом, необходимо его создать")
			raise SystemExit
		else:
			pass
		clear()
		remote_mode()
		clear()
	elif menu =="6":
		print(warning + " Установка обновления...")
		import files.updater
		time.sleep(2)
		clear()
		print(warning + " Распакуйте скачанный архив, и откройте программу")
		time.sleep(2)
		clear()
		print(successful)
		time.sleep(1)
		clear()
		raise SystemExit