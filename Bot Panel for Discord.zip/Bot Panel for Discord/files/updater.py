import requests, time

def update(file):
    filename = file.split('/')[-1]
    r = requests.get(file, allow_redirects=True)
    open(filename, 'wb').write(r.content)
    
file='https://github.com/VladislavNiceD/DMP/raw/main/Bot%20Panel%20for%20Discord.zip'
update(file)